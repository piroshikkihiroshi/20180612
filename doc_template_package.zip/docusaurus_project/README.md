# Docusaurus Project Placeholder

Initialize with `npx create-docusaurus@latest`