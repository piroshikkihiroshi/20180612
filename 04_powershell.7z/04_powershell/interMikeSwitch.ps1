﻿# 対象: デジタルマイク向けインテル® スマート・サウンド・テクノロジー
$partialHardwareID = "INTELAUDIO\CTLR_DEV_A0C8&LINKTYPE_02&DEVTYPE_00&VEN_8086&DEV_AE20&SUBSYS_04021854&REV_0001" # デバイスのハードウェアIDの一部を指定
$device = Get-PnpDevice | Where-Object { $_.HardwareID -contains $partialHardwareID }

if ($device -ne $null) {
    if ($device.Status -eq "OK") {
        # デバイスが有効な場合、無効化する
        Disable-PnpDevice -InstanceId $device.InstanceId -Confirm:$false
        exit 0
    } else {
        # デバイスが無効な場合、有効化する
        Enable-PnpDevice -InstanceId $device.InstanceId -Confirm:$false
        exit 0
    }
} else {
    Write-Host "指定されたデバイスが見つかりません。"
    exit 1
}
